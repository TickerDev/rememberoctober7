import { RemembrancePage } from "@/components/remembrance-page"

export default function Page() {
  return <RemembrancePage />
}